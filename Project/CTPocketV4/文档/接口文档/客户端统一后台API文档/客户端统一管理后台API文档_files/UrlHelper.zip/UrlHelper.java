package com.chinatelecom.tyml.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

/**
 * URL帮助类，提供通用的URL相关方法
 * @author xurui
 *
 */
public final class UrlHelper {
	
	private static final String TEXT_ENCODING = "utf-8";

	/**
	 * 对URL中的参数内容进行编码
	 * @param source 原始字符串
	 * @return 编码结果
	 * @throws UnsupportedEncodingException
	 */
	public static String encodeUrlParameter(final String source) throws UnsupportedEncodingException{
		if(source == null || source.equals("")){
			return "";
		}
		
		return URLEncoder.encode((new sun.misc.BASE64Encoder()).encode(source.getBytes(TEXT_ENCODING)), TEXT_ENCODING);
	}
	
	/**
	 * 对URL中的参数内容捷星解码
	 * @param source 编码后的字符串
	 * @return 解码内容
	 * @throws IOException
	 */
	public static String decodeUrlParameter(final String source) throws IOException{
		if(source == null || source.equals("")){
			return "";
		}
		
		return new String((new sun.misc.BASE64Decoder()).decodeBuffer(URLDecoder.decode(source, TEXT_ENCODING)), TEXT_ENCODING);
	}
}
